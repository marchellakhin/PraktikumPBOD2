/* Nama File    : Main.java
 * Deskripsi    : Berisi Class Main
 * Pembuat      : Marchella Arkhina Ratunesia
 * Tanggal      : Selasa, 28 April 2026
*/


public class Main {
    public static void main(String[] args) {
        Teman <String> m = new Teman<>();
        m.addnama("ali");
        m.addnama("azka");
        m.addnama("basil");
        m.addnama("caesar");
        m.addnama("devano");
        m.addnama("dinda");
        m.addnama("elza");
        m.addnama("ferdy");
        m.addnama("ghatfan");
        m.addnama("isan");
        m.addnama("hasta");
        m.addnama("ijat");
        m.addnama("cela");
        m.addnama("menza");
        m.addnama("rama");
        m.addnama("lutfi");
        m.addnama("naufal");
        m.addnama("atta");
        m.addnama("vela");
    }
}
